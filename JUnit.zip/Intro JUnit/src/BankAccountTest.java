


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.internal.Throwables;

public class BankAccountTest {

	private BankAccount account;
	private static int count;
	
	@BeforeClass
	public static void beforeClass() {
		System.out.println("this executes before any test cases Count = " + count++);
	}
	
	@Before
	public void setup() {
		account = new BankAccount("kent", "deleon", 1000.00, BankAccount.CHECKING);
		System.out.println("Running a test... Count = " + count++);
	}
	
	@Test
	public void deposit() throws Exception{ 
		double balance = account.deposit(100.00, true);
		assertEquals(1100, balance);
	}
	
	@Test
	public void withdraw_branch() throws Exception{
		double balance = account.withdraw(600.00, true);
		assertEquals(400, balance);
	}
	
	@Test //(expected = IllegalArgumentException.class)
	public void withdraw_notBranch() throws Exception{
		try { 
			account.withdraw(600, true);
			fail("Should have thrown an IllegalArgumentException");
		}catch(IllegalArgumentException e) {
			
		}
	}
	
	@Test
	public void getBalance_deposit() throws Exception{
		account.deposit(100.00, true);
		assertEquals(1100, account.getBalance());		
	}
	
	@Test
	public void getBalance_withdraw() throws Exception{
		account.withdraw(100.00, true);
		assertEquals(900, account.getBalance());		
	}
	

	@Test
	public void isChecking_true() throws Exception{
		assertTrue("The account is not a checking account ", account.isChecking());
	}
	
	@Test
	public void isChecking_false() throws Exception{
		account = new BankAccount("kent", "deleon", 1000.00, BankAccount.SAVINGS);
		assertFalse("THe account is a checking account ", account.isChecking());
	}
	
	@After
	public void tearDown() {
		System.out.println("Count = " + count++);
	}
	@AfterClass
	public static void afterClass() {
		System.out.println("this executes after any test cases");
	}
}

