
public class BankAccount {

	private String firstName;
	private String lastName;
	private double balance;
	public final static int SAVINGS = 1;
	public final static int CHECKING = 2;
	private int accountType;
	
	public BankAccount(String firstName, String lastName, double balance, int accountType) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.balance = balance;
		this.accountType = accountType;
	}

	// The branch argument is true if the customer is performing the transaction
	// at a branch with a teller
	// It is false if the customer is performing transaction at an ATM
	public double deposit(double amount, boolean branch) {
		this.balance += amount;

		return this.balance;

	}

	// The branch argument is true if the customer is performing the transaction
	// at a branch with a teller
	// It is false if the customer is performing transaction at an ATM
	public double withdraw(double amount, boolean branch) {
		if(amount > 500 && !branch) {
			throw new IllegalArgumentException();
		}
		
		this.balance -= amount;

		return this.balance;

	}

	public double getBalance() {
		return this.balance;
	}
	
	public boolean isChecking() {
		return this.accountType == CHECKING;
	}

}
